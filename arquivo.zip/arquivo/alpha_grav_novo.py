"""
Gravitational Signatures Framework
===================================

Testa a universalidade do α_grav através do processo estocástico OU.

Conceito:
- Cada partícula tem α_grav = G·m²/(ℏ·c)
- Roda processo OU com alvo em α_EM ≈ 1/137.036
- t < 50: aleatoriedade pura
- t ≥ 50: emergência do sinal
- Diferença entre valor emergido e 137.036 = "assinatura gravitacional"

Física:
- Partículas reais devem convergir próximo de 137.036
- Números aleatórios permanecem dispersos
- A assinatura é característica da partícula
"""

import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass
from typing import List, Tuple
import scipy.constants as const

# Constantes físicas
G = const.G  # 6.67430e-11 m³/(kg·s²)
hbar = const.hbar  # 1.054571817e-34 J·s
c = const.c  # 299792458 m/s
ALPHA_EM = 137.035999084  # 1/α_EM (constante de estrutura fina inversa)

@dataclass
class Particle:
    """Representa uma partícula com suas propriedades físicas"""
    name: str
    mass: float  # kg
    charge: float = 0.0  # em unidades de e
    spin: float = 0.0
    
    def alpha_grav(self) -> float:
        """Calcula α_grav = G·m²/(ℏ·c)"""
        return (G * self.mass**2) / (hbar * c)

# Partículas do Standard Model
PARTICLES = [
    # Léptons
    Particle("electron", 9.1093837015e-31, -1, 0.5),
    Particle("muon", 1.883531627e-28, -1, 0.5),
    Particle("tau", 3.16754e-27, -1, 0.5),
    
    # Quarks (massas de pólo)
    Particle("up", 3.8e-30, 2/3, 0.5),
    Particle("down", 8.6e-30, -1/3, 0.5),
    Particle("charm", 2.275e-27, 2/3, 0.5),
    Particle("strange", 1.7e-28, -1/3, 0.5),
    Particle("top", 3.078e-25, 2/3, 0.5),
    Particle("bottom", 7.54e-27, -1/3, 0.5),
    
    # Bosons
    Particle("W", 1.433e-25, 1, 1),
    Particle("Z", 1.625e-25, 0, 1),
    Particle("Higgs", 2.239e-25, 0, 0),
    
    # Núcleons (compostos, para comparação)
    Particle("proton", 1.67262192369e-27, 1, 0.5),
    Particle("neutron", 1.67492749804e-27, 0, 0.5),
]


def ornstein_uhlenbeck_process(
    x0: float,
    target: float,
    theta: float = 1.0,
    sigma: float = 1.0,
    dt: float = 1.0,
    n_steps: int = 200
) -> np.ndarray:
    """
    Processo Ornstein-Uhlenbeck com SNR = 0.05√t
    
    dx = θ(μ - x)dt + σ·dW
    
    Parâmetros:
    -----------
    x0 : float
        Valor inicial (α_grav da partícula)
    target : float
        Alvo (α_EM ≈ 137.036)
    theta : float
        Taxa de reversão à média
    sigma : float
        Volatilidade base
    dt : float
        Passo de tempo
    n_steps : int
        Número de iterações
    
    Retorna:
    --------
    trajectory : np.ndarray
        Trajetória completa do processo
    """
    trajectory = np.zeros(n_steps)
    trajectory[0] = x0
    
    for t in range(1, n_steps):
        # SNR = 0.05√t
        snr = 0.05 * np.sqrt(t)
        
        # Ruído gaussiano modulado pelo SNR
        noise = np.random.normal(0, 1) * sigma / (1 + snr)
        
        # Equação OU
        dx = theta * (target - trajectory[t-1]) * dt + noise
        trajectory[t] = trajectory[t-1] + dx
    
    return trajectory


def calculate_signature(
    particle: Particle,
    n_simulations: int = 100,
    n_steps: int = 200,
    threshold_t: int = 50
) -> Tuple[float, float, np.ndarray]:
    """
    Calcula a assinatura gravitacional de uma partícula
    
    Retorna:
    --------
    signature_mean : float
        Diferença média entre valor emergido e α_EM
    signature_std : float
        Desvio padrão da assinatura
    all_trajectories : np.ndarray
        Todas as trajetórias simuladas (para análise)
    """
    α_initial = particle.alpha_grav()
    all_trajectories = np.zeros((n_simulations, n_steps))
    signatures = np.zeros(n_simulations)
    
    for i in range(n_simulations):
        trajectory = ornstein_uhlenbeck_process(
            x0=α_initial,
            target=ALPHA_EM,
            n_steps=n_steps
        )
        all_trajectories[i] = trajectory
        
        # Valor emergente após t ≥ 50
        emerged_value = np.mean(trajectory[threshold_t:])
        
        # Assinatura = diferença do alvo
        signatures[i] = abs(emerged_value - ALPHA_EM)
    
    return np.mean(signatures), np.std(signatures), all_trajectories


def test_random_numbers(
    n_random: int = 10,
    n_simulations: int = 100,
    n_steps: int = 200,
    threshold_t: int = 50
) -> List[float]:
    """
    Testa números aleatórios como controle
    
    Números aleatórios não devem convergir próximo de α_EM
    """
    random_signatures = []
    
    for _ in range(n_random):
        # Gera α_grav "fake" em mesma ordem de grandeza
        fake_alpha = np.random.uniform(1e-50, 1e-35)
        
        signatures = []
        for _ in range(n_simulations):
            trajectory = ornstein_uhlenbeck_process(
                x0=fake_alpha,
                target=ALPHA_EM,
                n_steps=n_steps
            )
            emerged_value = np.mean(trajectory[threshold_t:])
            signatures.append(abs(emerged_value - ALPHA_EM))
        
        random_signatures.append(np.mean(signatures))
    
    return random_signatures


def analyze_universality():
    """
    Análise completa da universalidade das assinaturas
    """
    print("=" * 80)
    print("ANÁLISE DE ASSINATURAS GRAVITACIONAIS")
    print("=" * 80)
    print(f"\nAlvo (1/α_EM): {ALPHA_EM:.6f}")
    print(f"Threshold de emergência: t ≥ 50")
    print(f"SNR = 0.05√t\n")
    
    # Calcula assinaturas para todas as partículas
    results = []
    
    print("-" * 80)
    print(f"{'Partícula':<15} {'α_grav':<15} {'Assinatura':<15} {'σ':<15}")
    print("-" * 80)
    
    for particle in PARTICLES:
        sig_mean, sig_std, trajectories = calculate_signature(particle)
        results.append({
            'particle': particle,
            'signature': sig_mean,
            'std': sig_std,
            'trajectories': trajectories
        })
        
        print(f"{particle.name:<15} {particle.alpha_grav():<15.3e} "
              f"{sig_mean:<15.6f} {sig_std:<15.6f}")
    
    # Testa números aleatórios como controle
    print("\n" + "=" * 80)
    print("CONTROLE: NÚMEROS ALEATÓRIOS")
    print("=" * 80)
    
    random_sigs = test_random_numbers(n_random=10)
    print(f"\nAssinatura média (random): {np.mean(random_sigs):.6f}")
    print(f"Desvio padrão (random): {np.std(random_sigs):.6f}")
    
    # Comparação estatística
    particle_sigs = [r['signature'] for r in results]
    print("\n" + "=" * 80)
    print("ANÁLISE ESTATÍSTICA")
    print("=" * 80)
    print(f"\nPartículas reais:")
    print(f"  Assinatura média: {np.mean(particle_sigs):.6f}")
    print(f"  Desvio padrão: {np.std(particle_sigs):.6f}")
    print(f"  Min: {np.min(particle_sigs):.6f}")
    print(f"  Max: {np.max(particle_sigs):.6f}")
    
    print(f"\nNúmeros aleatórios:")
    print(f"  Assinatura média: {np.mean(random_sigs):.6f}")
    print(f"  Desvio padrão: {np.std(random_sigs):.6f}")
    
    # Teste de significância
    ratio = np.mean(random_sigs) / np.mean(particle_sigs)
    print(f"\nRazão (random/particles): {ratio:.2f}x")
    
    if ratio > 2:
        print("✓ Partículas reais SIGNIFICATIVAMENTE mais próximas de α_EM!")
    else:
        print("✗ Diferença não significativa - revisar modelo")
    
    return results, random_sigs


def plot_results(results, random_sigs):
    """
    Visualiza os resultados
    """
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    # 1. Assinaturas por partícula
    ax1 = axes[0, 0]
    names = [r['particle'].name for r in results]
    sigs = [r['signature'] for r in results]
    colors = plt.cm.viridis(np.linspace(0, 1, len(names)))
    
    ax1.barh(names, sigs, color=colors)
    ax1.axvline(np.mean(random_sigs), color='red', linestyle='--', 
                label='Média Random', linewidth=2)
    ax1.set_xlabel('Assinatura Gravitacional')
    ax1.set_title('Assinaturas por Partícula')
    ax1.legend()
    ax1.grid(alpha=0.3)
    
    # 2. Exemplo de trajetória (elétron)
    ax2 = axes[0, 1]
    electron_traj = results[0]['trajectories'][0]
    t_range = np.arange(len(electron_traj))
    
    ax2.plot(t_range, electron_traj, label='Trajetória', alpha=0.7)
    ax2.axhline(ALPHA_EM, color='red', linestyle='--', label='α_EM (alvo)')
    ax2.axvline(50, color='green', linestyle=':', label='t = 50 (threshold)')
    ax2.set_xlabel('t (iterações)')
    ax2.set_ylabel('Valor')
    ax2.set_title(f'Trajetória Exemplo: {results[0]["particle"].name}')
    ax2.legend()
    ax2.grid(alpha=0.3)
    
    # 3. Distribuição de assinaturas
    ax3 = axes[1, 0]
    particle_sigs = [r['signature'] for r in results]
    
    ax3.hist(particle_sigs, bins=15, alpha=0.7, label='Partículas', color='blue')
    ax3.hist(random_sigs, bins=15, alpha=0.7, label='Random', color='red')
    ax3.set_xlabel('Assinatura')
    ax3.set_ylabel('Frequência')
    ax3.set_title('Distribuição: Partículas vs Random')
    ax3.legend()
    ax3.grid(alpha=0.3)
    
    # 4. α_grav vs Assinatura
    ax4 = axes[1, 1]
    alphas = [r['particle'].alpha_grav() for r in results]
    
    ax4.scatter(alphas, sigs, c=colors, s=100, alpha=0.7)
    for i, r in enumerate(results):
        ax4.annotate(r['particle'].name, (alphas[i], sigs[i]), 
                    fontsize=8, alpha=0.7)
    ax4.set_xlabel('α_grav')
    ax4.set_ylabel('Assinatura')
    ax4.set_title('α_grav vs Assinatura Gravitacional')
    ax4.set_xscale('log')
    ax4.grid(alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/gravitational_signatures.png', dpi=300, bbox_inches='tight')
    print("\n✓ Gráfico salvo: gravitational_signatures.png")


if __name__ == "__main__":
    # Seed para reprodutibilidade
    np.random.seed(42)
    
    # Roda análise completa
    results, random_sigs = analyze_universality()
    
    # Gera visualizações
    plot_results(results, random_sigs)
    
    print("\n" + "=" * 80)
    print("ANÁLISE COMPLETA!")
    print("=" * 80)