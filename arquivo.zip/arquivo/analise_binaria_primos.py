#!/usr/bin/env python3
"""
Análise de Padrões Binários em Primos Gêmeos
Investiga correlações na representação binária dos primos
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import signal, stats
from collections import Counter
import warnings
warnings.filterwarnings('ignore')

# ==============================================================================
# ANÁLISE DE REPRESENTAÇÃO BINÁRIA
# ==============================================================================

def analisar_bits(numero):
    """Analisa propriedades da representação binária"""
    bin_str = bin(numero)[2:]  # Remove '0b'
    
    return {
        'num_bits': len(bin_str),
        'num_ones': bin_str.count('1'),
        'num_zeros': bin_str.count('0'),
        'densidade_ones': bin_str.count('1') / len(bin_str),
        'bin_str': bin_str
    }

def calcular_hamming_weight(numero):
    """Retorna número de bits '1' (peso de Hamming)"""
    return bin(numero).count('1')

def calcular_entropia_binaria(numero):
    """Calcula entropia da representação binária"""
    bin_str = bin(numero)[2:]
    n = len(bin_str)
    if n == 0:
        return 0
    
    p1 = bin_str.count('1') / n
    p0 = 1 - p1
    
    entropy = 0
    if p1 > 0:
        entropy -= p1 * np.log2(p1)
    if p0 > 0:
        entropy -= p0 * np.log2(p0)
    
    return entropy

def calcular_runs_binarios(numero):
    """Calcula número de 'runs' (sequências consecutivas de mesmo bit)"""
    bin_str = bin(numero)[2:]
    if len(bin_str) <= 1:
        return 1
    
    runs = 1
    for i in range(1, len(bin_str)):
        if bin_str[i] != bin_str[i-1]:
            runs += 1
    
    return runs

def analisar_xor_gaps(p1, p2):
    """Analisa XOR entre primos gêmeos (p e p+2)"""
    xor_val = p1 ^ p2
    
    return {
        'xor': xor_val,
        'xor_hamming': calcular_hamming_weight(xor_val),
        'xor_bits': bin(xor_val)[2:],
        'xor_entropia': calcular_entropia_binaria(xor_val)
    }

def calcular_k_real_binario(p1, p2):
    """
    Calcula k_real via análise binária
    k_real mede quantos bits consecutivos são idênticos a partir do LSB
    """
    xor = p1 ^ p2
    
    # Contar trailing zeros (bits idênticos da direita)
    if xor == 0:
        return 64  # Todos os bits iguais (improvável)
    
    # Contar quantos bits à direita são zero no XOR
    k = 0
    while (xor & 1) == 0:
        xor >>= 1
        k += 1
    
    return k

# ==============================================================================
# ANÁLISE ESTATÍSTICA DE PADRÕES BINÁRIOS
# ==============================================================================

def analisar_distribuicao_hamming(primos):
    """Analisa distribuição de peso de Hamming"""
    hamming_weights = [calcular_hamming_weight(p) for p in primos]
    
    counter = Counter(hamming_weights)
    
    print("Distribuição de Peso de Hamming (número de bits '1'):")
    for hw in sorted(counter.keys()):
        count = counter[hw]
        pct = 100 * count / len(primos)
        print(f"  {hw:2d} bits: {count:8d} ({pct:5.2f}%)")
    
    return np.array(hamming_weights)

def analisar_entropia(primos):
    """Analisa entropia binária dos primos"""
    entropias = [calcular_entropia_binaria(p) for p in primos]
    
    print(f"\nEntropia Binária:")
    print(f"  Média: {np.mean(entropias):.6f}")
    print(f"  Desvio: {np.std(entropias):.6f}")
    print(f"  Mín: {np.min(entropias):.6f}")
    print(f"  Máx: {np.max(entropias):.6f}")
    
    return np.array(entropias)

def analisar_runs(primos, sample_size=10000):
    """Analisa runs binários (amostragem para performance)"""
    if len(primos) > sample_size:
        primos_sample = np.random.choice(primos, sample_size, replace=False)
    else:
        primos_sample = primos
    
    runs = [calcular_runs_binarios(p) for p in primos_sample]
    
    print(f"\nRuns Binários (amostra de {len(primos_sample)}):")
    print(f"  Média: {np.mean(runs):.2f}")
    print(f"  Desvio: {np.std(runs):.2f}")
    print(f"  Mín: {np.min(runs)}")
    print(f"  Máx: {np.max(runs)}")
    
    return np.array(runs)

def analisar_xor_twin_primes(primos_df):
    """
    Analisa propriedades do XOR entre primos gêmeos
    Formato esperado: p, p+2, k_real, ...
    """
    print("\n" + "="*80)
    print("ANÁLISE XOR ENTRE PRIMOS GÊMEOS (p XOR p+2)")
    print("="*80)
    
    p1 = primos_df.iloc[:, 0].values  # Primeiro primo
    p2 = primos_df.iloc[:, 1].values  # p + 2
    
    # XOR values
    xor_vals = p1 ^ p2
    
    # Análise estatística
    print(f"\nEstatísticas XOR:")
    print(f"  Valores únicos: {len(np.unique(xor_vals))}")
    print(f"  Valor mais comum: {stats.mode(xor_vals, keepdims=True)[0][0]}")
    
    # Distribuição de XOR
    counter = Counter(xor_vals)
    print(f"\nTop 10 valores XOR mais frequentes:")
    for i, (xor_val, count) in enumerate(counter.most_common(10), 1):
        pct = 100 * count / len(xor_vals)
        print(f"  {i:2d}. XOR={xor_val:20d} (0b{bin(xor_val)[2:]:>64s}) | {count:8d} ({pct:5.2f}%)")
    
    # Hamming weight do XOR
    xor_hamming = np.array([calcular_hamming_weight(x) for x in xor_vals[:10000]])  # Sample
    print(f"\nPeso de Hamming do XOR (amostra 10k):")
    print(f"  Média: {np.mean(xor_hamming):.2f}")
    print(f"  Desvio: {np.std(xor_hamming):.2f}")
    print(f"  Mín: {np.min(xor_hamming)}")
    print(f"  Máx: {np.max(xor_hamming)}")
    
    return xor_vals, xor_hamming

def analisar_k_real_binario(primos_df):
    """
    Analisa k_real calculado via método binário
    Compara com k_real do CSV (se disponível)
    """
    print("\n" + "="*80)
    print("ANÁLISE k_real VIA MÉTODO BINÁRIO")
    print("="*80)
    
    p1 = primos_df.iloc[:, 0].values
    p2 = primos_df.iloc[:, 1].values
    
    # Calcular k_real binário (sample para performance)
    sample_size = min(100000, len(p1))
    indices = np.random.choice(len(p1), sample_size, replace=False)
    
    k_binario = []
    for i in indices:
        k = calcular_k_real_binario(p1[i], p2[i])
        k_binario.append(k)
    
    k_binario = np.array(k_binario)
    
    # Distribuição de k_real
    counter = Counter(k_binario)
    print(f"\nDistribuição de k_real (amostra {sample_size}):")
    
    total = len(k_binario)
    k_esperado_teorico = {}
    
    for k in sorted(counter.keys()):
        count = counter[k]
        pct_obs = 100 * count / total
        
        # P(k) = 2^(-k) teórico
        pct_teorico = 100 * (2.0**(-k))
        
        k_esperado_teorico[k] = pct_teorico
        erro = abs(pct_obs - pct_teorico)
        
        print(f"  k={k:2d}: Obs={count:6d} ({pct_obs:6.3f}%) | Teórico={pct_teorico:6.3f}% | Erro={erro:6.3f}%")
    
    # Se k_real existe no CSV (coluna 2)
    if primos_df.shape[1] > 2:
        k_csv = primos_df.iloc[indices, 2].values
        
        # Comparar
        concordancia = np.sum(k_binario == k_csv) / len(k_binario)
        print(f"\n✓ Concordância com k_real do CSV: {100*concordancia:.2f}%")
        
        if concordancia < 1.0:
            discordantes = np.where(k_binario != k_csv)[0]
            print(f"  ⚠ {len(discordantes)} discordâncias detectadas")
            
            # Mostrar exemplos
            print("\n  Exemplos de discordâncias:")
            for idx in discordantes[:5]:
                i = indices[idx]
                print(f"    p1={p1[i]}, p2={p2[i]}")
                print(f"      k_binario={k_binario[idx]}, k_csv={k_csv[idx]}")
    
    return k_binario, counter

def analisar_bit_patterns(primos, num_bits=10):
    """
    Analisa padrões de bits mais significativos
    """
    print("\n" + "="*80)
    print(f"ANÁLISE DE PADRÕES DOS {num_bits} BITS MAIS SIGNIFICATIVOS")
    print("="*80)
    
    patterns = []
    for p in primos:
        bin_str = bin(p)[2:]
        if len(bin_str) >= num_bits:
            pattern = bin_str[:num_bits]
            patterns.append(pattern)
    
    counter = Counter(patterns)
    print(f"\nTop 20 padrões mais comuns:")
    for i, (pattern, count) in enumerate(counter.most_common(20), 1):
        pct = 100 * count / len(patterns)
        print(f"  {i:2d}. {pattern:s} | {count:8d} ({pct:5.2f}%)")
    
    # Entropia dos padrões
    probs = np.array([count/len(patterns) for count in counter.values()])
    entropy = -np.sum(probs * np.log2(probs))
    max_entropy = np.log2(2**num_bits)  # Entropia máxima possível
    
    print(f"\nEntropia dos padrões:")
    print(f"  Observada: {entropy:.4f} bits")
    print(f"  Máxima possível: {max_entropy:.4f} bits")
    print(f"  Normalizada: {entropy/max_entropy:.4f}")
    
    return patterns, counter

# ==============================================================================
# VISUALIZAÇÃO
# ==============================================================================

def plotar_analise_binaria(primos_df, hamming_weights, entropias, xor_vals, k_binario):
    """Cria visualizações da análise binária"""
    
    fig = plt.figure(figsize=(18, 12))
    
    # 1. Distribuição de Hamming Weight
    ax1 = plt.subplot(3, 3, 1)
    bins = np.arange(np.min(hamming_weights), np.max(hamming_weights)+2) - 0.5
    ax1.hist(hamming_weights, bins=bins, alpha=0.7, edgecolor='black')
    ax1.set_xlabel('Peso de Hamming (número de bits 1)')
    ax1.set_ylabel('Frequência')
    ax1.set_title('Distribuição de Peso de Hamming')
    ax1.grid(True, alpha=0.3)
    
    # Distribuição binomial esperada (p=0.5)
    num_bits = int(np.log2(primos_df.iloc[0, 0])) + 1
    x = np.arange(num_bits+1)
    binom = stats.binom(num_bits, 0.5)
    ax1_twin = ax1.twinx()
    ax1_twin.plot(x, binom.pmf(x) * len(hamming_weights), 'r--', label='Binomial (p=0.5)', linewidth=2)
    ax1_twin.set_ylabel('Esperado (binomial)', color='r')
    
    # 2. Entropia Binária
    ax2 = plt.subplot(3, 3, 2)
    ax2.hist(entropias, bins=50, alpha=0.7, edgecolor='black')
    ax2.axvline(1.0, color='r', linestyle='--', linewidth=2, label='Máximo (1.0)')
    ax2.set_xlabel('Entropia Binária')
    ax2.set_ylabel('Frequência')
    ax2.set_title('Distribuição de Entropia Binária')
    ax2.legend()
    ax2.grid(True, alpha=0.3)
    
    # 3. Distribuição XOR
    ax3 = plt.subplot(3, 3, 3)
    xor_unique, xor_counts = np.unique(xor_vals, return_counts=True)
    ax3.bar(range(len(xor_unique[:20])), xor_counts[:20], alpha=0.7, edgecolor='black')
    ax3.set_xlabel('XOR Value (top 20)')
    ax3.set_ylabel('Frequência')
    ax3.set_title('Distribuição XOR (p ⊕ p+2)')
    ax3.grid(True, alpha=0.3)
    
    # 4. k_real Observado vs Teórico
    ax4 = plt.subplot(3, 3, 4)
    k_vals, k_counts = np.unique(k_binario, return_counts=True)
    k_obs_pct = 100 * k_counts / len(k_binario)
    k_teorico_pct = 100 * (2.0 ** (-k_vals))
    
    x_pos = np.arange(len(k_vals))
    width = 0.35
    ax4.bar(x_pos - width/2, k_obs_pct, width, label='Observado', alpha=0.7)
    ax4.bar(x_pos + width/2, k_teorico_pct, width, label='Teórico P(k)=2^(-k)', alpha=0.7)
    ax4.set_xlabel('k_real')
    ax4.set_ylabel('Porcentagem (%)')
    ax4.set_title('Distribuição k_real: Observado vs Teórico')
    ax4.set_xticks(x_pos)
    ax4.set_xticklabels(k_vals)
    ax4.legend()
    ax4.grid(True, alpha=0.3)
    
    # 5. Hamming Weight vs Entropia
    ax5 = plt.subplot(3, 3, 5)
    ax5.scatter(hamming_weights, entropias, alpha=0.1, s=1)
    ax5.set_xlabel('Peso de Hamming')
    ax5.set_ylabel('Entropia Binária')
    ax5.set_title('Hamming Weight vs Entropia')
    ax5.grid(True, alpha=0.3)
    
    # 6. Bits LSB (Least Significant Bits) - Padrão dos últimos 8 bits
    ax6 = plt.subplot(3, 3, 6)
    p1 = primos_df.iloc[:, 0].values
    lsb_patterns = [(p & 0xFF) for p in p1[:10000]]  # 8 bits menos significativos
    ax6.hist(lsb_patterns, bins=256, alpha=0.7, edgecolor='black')
    ax6.set_xlabel('Valor dos 8 LSB')
    ax6.set_ylabel('Frequência')
    ax6.set_title('Distribuição dos 8 Bits Menos Significativos')
    ax6.grid(True, alpha=0.3)
    
    # 7. Teste de Aleatoriedade: Bit Flip Frequency
    ax7 = plt.subplot(3, 3, 7)
    # Calcular frequência de transição de bit
    sample_primos = primos_df.iloc[:1000, 0].values
    bit_flips = []
    for p in sample_primos:
        runs = calcular_runs_binarios(p)
        num_bits = len(bin(p)[2:])
        bit_flips.append(runs / num_bits if num_bits > 0 else 0)
    
    ax7.hist(bit_flips, bins=30, alpha=0.7, edgecolor='black')
    ax7.axvline(0.5, color='r', linestyle='--', linewidth=2, label='Esperado (random)')
    ax7.set_xlabel('Runs / Número de Bits')
    ax7.set_ylabel('Frequência')
    ax7.set_title('Taxa de Transição de Bits (Aleatoriedade)')
    ax7.legend()
    ax7.grid(True, alpha=0.3)
    
    # 8. Correlação entre bits consecutivos
    ax8 = plt.subplot(3, 3, 8)
    p1_sample = primos_df.iloc[:10000, 0].values
    
    # Calcular autocorrelação de bits
    correlations = []
    for p in p1_sample:
        bin_str = bin(p)[2:]
        bits = np.array([int(b) for b in bin_str])
        if len(bits) > 1:
            corr = np.corrcoef(bits[:-1], bits[1:])[0, 1]
            correlations.append(corr)
    
    ax8.hist(correlations, bins=30, alpha=0.7, edgecolor='black')
    ax8.axvline(0, color='r', linestyle='--', linewidth=2, label='Sem correlação')
    ax8.set_xlabel('Correlação entre bits consecutivos')
    ax8.set_ylabel('Frequência')
    ax8.set_title('Autocorrelação de Bits')
    ax8.legend()
    ax8.grid(True, alpha=0.3)
    
    # 9. Distribuição de paridade
    ax9 = plt.subplot(3, 3, 9)
    paridades = [calcular_hamming_weight(p) % 2 for p in p1[:10000]]
    counter_paridade = Counter(paridades)
    ax9.bar(['Par', 'Ímpar'], [counter_paridade[0], counter_paridade[1]], alpha=0.7, edgecolor='black')
    ax9.set_ylabel('Frequência')
    ax9.set_title('Paridade do Peso de Hamming')
    ax9.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('/home/thlinux/relacionalidadegeral/resultados/graficos/analise_binaria_primos.png', 
                dpi=150, bbox_inches='tight')
    print("\n✓ Gráfico salvo: analise_binaria_primos.png")

# ==============================================================================
# FUNÇÃO PRINCIPAL
# ==============================================================================

def analisar_binario_completo(arquivo_csv, max_linhas=None):
    """Análise completa de padrões binários"""
    
    print("="*80)
    print("ANÁLISE BINÁRIA DE PRIMOS GÊMEOS")
    print("="*80)
    
    # Carregar dados
    try:
        if max_linhas:
            df = pd.read_csv(arquivo_csv, nrows=max_linhas)
        else:
            df = pd.read_csv(arquivo_csv)
        
        print(f"✓ Carregados {len(df)} pares de primos gêmeos")
        print(f"  Range: {df.iloc[:, 0].min():.6e} → {df.iloc[:, 0].max():.6e}\n")
        
    except Exception as e:
        print(f"✗ Erro: {e}")
        return None
    
    # Análises
    primos = df.iloc[:, 0].values
    
    # 1. Hamming weight
    print("="*80)
    print("1. ANÁLISE DE PESO DE HAMMING")
    print("="*80)
    hamming_weights = analisar_distribuicao_hamming(primos[:100000])
    
    # 2. Entropia
    print("\n" + "="*80)
    print("2. ANÁLISE DE ENTROPIA BINÁRIA")
    print("="*80)
    entropias = analisar_entropia(primos[:100000])
    
    # 3. Runs
    print("\n" + "="*80)
    print("3. ANÁLISE DE RUNS BINÁRIOS")
    print("="*80)
    runs = analisar_runs(primos, sample_size=10000)
    
    # 4. XOR entre pares
    xor_vals, xor_hamming = analisar_xor_twin_primes(df[:100000])
    
    # 5. k_real binário
    k_binario, k_counter = analisar_k_real_binario(df)
    
    # 6. Padrões de bits
    patterns, pattern_counter = analisar_bit_patterns(primos[:10000], num_bits=10)
    
    # Visualização
    print("\n" + "="*80)
    print("GERANDO VISUALIZAÇÕES")
    print("="*80)
    plotar_analise_binaria(df, hamming_weights, entropias, xor_vals, k_binario)
    
    print("\n" + "="*80)
    print("✓ ANÁLISE BINÁRIA CONCLUÍDA")
    print("="*80)
    
    return {
        'hamming_weights': hamming_weights,
        'entropias': entropias,
        'runs': runs,
        'xor_vals': xor_vals,
        'k_binario': k_binario
    }

# ==============================================================================
# EXECUÇÃO
# ==============================================================================

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        arquivo = sys.argv[1]
    else:
        arquivo = "/home/thlinux/relacionalidadegeral/codigo/binario/results.csv"
        print(f"Usando arquivo padrão: {arquivo}\n")
    
    max_linhas = int(sys.argv[2]) if len(sys.argv) > 2 else None
    
    if max_linhas:
        print(f"⚠ Modo teste: analisando {max_linhas} linhas\n")
    
    resultados = analisar_binario_completo(arquivo, max_linhas=max_linhas)
